const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const passwordConfirmation = document.getElementById("password-confirmation");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  var nomeusuario = getElementById("username").value;
  var conv = document.getElementById("email").value;
  var RG = document.getElementById("password").value;
  var ender = document.getElementById("password-confirmation").value;
  checkInputs();

  let dados = new array();
  if(localStorage.hasOwnPropety("dados")){
    dados = JSON.parse(localStorage.getItem("dados"));
  }
  dados.push({nome_usuario: nomeusuario, convenho: conv, RG: RG, endereco: ender})
  localStorage.setItem("dados", JSON.stringfy(dados))
  document.getElementById("conteudo").insertAdjacentHTML('beforeend', "Nome: " + nomeusuario + "<br>Convenho: " + conv + "<br>RG: " + RG + "<br>Endereço: " + ender + "<br><hr>"
});

function checkInputs() {
  const usernameValue = username.value;
  const emailValue = email.value;
  const passwordValue = password.value;
  const passwordConfirmationValue = passwordConfirmation.value;
  
  if (usernameValue === "") {
    setErrorFor(username, "O nome de nome é obrigatório.");
  } else {
    setSuccessFor(username);
  }

  if (emailValue === "") {
    setErrorFor(email, "O convenho é obrigatório.");
  } else if (!checkEmail(emailValue)) {
    setErrorFor(email, "Por favor, insira um convenho válido.");
  } else {
    setSuccessFor(email);
  }

  if (passwordValue === "") {
    setErrorFor(password, "O RG é obrigatório.");
  } else if (passwordValue.length < 7) {
    setErrorFor(password, "O RG precisa ter 8 dígitos.");
  } else {
    setSuccessFor(password);
  }

  const formControls = form.querySelectorAll(".form-control");

  const formIsValid = [...formControls].every((formControl) => {
    return formControl.className === "form-control success";
  });

  if (formIsValid) {
    console.log("O formulário está 100% válido!");
  }
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");


  small.innerText = message;


  formControl.className = "form-control error";
}

function setSuccessFor(input) {
  const formControl = input.parentElement;


  formControl.className = "form-control success";
}

function checkEmail(email) {
  return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
    email
  );
}